==================================================================================== 
 1. Run setup 
 Password is 2022
 Please use the above password to extract setup file. 
 2. Install
 3. Run installed software
 ==================================================================================== 